window.location = "/OmatSivut/Apps/Iptv/index.jsp";
